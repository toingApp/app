<?php  
foreach (glob("../Salas/*.html") as $file) {
if(time() - filectime($file) > 1900){
 unlink($file);  } } 
 
$folders = [ '../usuarios/1/1/{,.}*', '../usuarios/1/2/{,.}*', '../usuarios/2/1/{,.}*', '../usuarios/2/2/{,.}*', '../usuarios/3/1/{,.}*',   '../usuarios/3/2/{,.}*','../usuarios/4/1/{,.}*', '../usuarios/4/2/{,.}*', '../usuarios/5/1/{,.}*','../usuarios/5/2/{,.}'];
foreach($folders as $folder) {
 $files = glob($folder, GLOB_BRACE); 
  foreach($files as $file){ 
if(time() - filectime($file) > 1200){
 unlink($file);  } } } 

foreach (glob("../usuarios/global/{,.}*",GLOB_BRACE) as $file) {
if(time() - filectime($file) > 172800){
 unlink($file);  } } 
 
session_start(); 
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
   session_unset(); 
   session_destroy();  }
 $_SESSION['LAST_ACTIVITY'] = time(); 
 
if (isset($_SESSION['nombre'])) { ?>
<?php header('Loged: yesloged'); ?>
<?php } else{?>
	<?php header('Loged: nologed');?>
<?php }?>