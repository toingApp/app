<?php ob_start();  ob_flush();   
 header("Content-Type: text/plain");   session_start(); if (isset($_SESSION['nombre'])) { 
if($_GET['item']=='1' || $_GET['item']=='2' || $_GET['item']=='3' ||
$_GET['item']=='4' || $_GET['item']=='5') {
if($_GET['id']=='1' || $_GET['id']=='2' || $_GET['id']=='3' ||
$_GET['id']=='4' || $_GET['id']=='5') {
 $users = $_SESSION['nombre'];

$item = $_GET['item'];
$id = $_GET['id'];
if($item=='1' || $item=='2' || $item=='3' || $item=='4' || $item=='5') {
$a ="../usuarios/".$item."/".$id."/".$users;
fopen("../usuarios/".$item."/".$id."/".$users, w); }
$b = array(
"../usuarios/1/1/".$users,
"../usuarios/1/2/".$users,
"../usuarios/2/1/".$users,
"../usuarios/2/2/".$users,
"../usuarios/3/1/".$users,
"../usuarios/3/2/".$users,
"../usuarios/4/1/".$users,
"../usuarios/4/2/".$users,
"../usuarios/5/1/".$users,
"../usuarios/5/2/".$users
);
foreach($b as $bi) { 
if($bi != $a) {unlink($bi); } } 

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
   session_unset(); 
    session_destroy();  
unlink("../usuarios/1/1/".$users);
unlink("../usuarios/1/2/".$users);
unlink("../usuarios/2/1/".$users);
unlink("../usuarios/2/2/".$users);
unlink("../usuarios/3/1/".$users);
unlink("../usuarios/3/2/".$users);
unlink("../usuarios/4/1/".$users);
unlink("../usuarios/4/2/".$users);
unlink("../usuarios/5/1/".$users);
unlink("../usuarios/5/2/".$users);
unlink("../usuarios/global/".$users); }
 $_SESSION['LAST_ACTIVITY'] = time(); 
 if($_GET['para']=='para') {
 	echo "*TODOS*\n";
$dir=opendir("../usuarios/".$_GET['item']."/".$_GET['id']."/");
while(($archivo = readdir($dir)) !== false){
if ( ($archivo != '.') and ($archivo != '..') and ($archivo !=$users))
{$store[$sum] = $archivo; $sum++; } }
natcasesort($store); foreach($store as $item => $archivo){
 echo $archivo."\n";  }  }
   
 if($_GET['chats']=='chats') {
$lines = file("../Salas/msg".$_GET['item']."_".$_GET['id'].".html");
$des = $users."875";  $c =true;
if(file_exists("../Salas/msg".$item."_".$id.".html")) {
foreach($lines as $line) { $ve_vi =(($c = !$c)?'violeta':'verde');
$row = explode("|", $line);
if (strpos($line,$des)) {
echo $row[1]."|".$row[2]."|".$row[3]."|".$row[4]."|".$ve_vi."| \n";
} else {  if(!strstr($line,"R42T03")) {
$row1 = explode("|", $line);
echo $row1[1]."|".$row1[2]."|".$row1[3]."|".$row1[4]."|".$ve_vi."| \n"; } 
}  }    }else{ echo"No hay mensajes recientes.||||violeta| \n";  }  }
} } }?>