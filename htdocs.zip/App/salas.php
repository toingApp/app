<?php ob_start();  ob_flush(); 
 header("Content-Type: text/plain"); 
if($_GET['ListAll']=='ListAll') { 
echo "Mas de 30|"; echo count(glob("../usuarios/4/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("../usuarios/4/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|4| \n";
  echo "Placer|"; echo count(glob("../usuarios/3/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("../usuarios/3/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|3| \n";
 echo "Amor|"; echo count(glob("../usuarios/2/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("../usuarios/2/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|2| \n";
echo "Amigos|"; echo count(glob("../usuarios/1/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("../usuarios/1/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|1| \n";
 echo "Sexo|"; echo count(glob("../usuarios/5/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("../usuarios/5/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|5| \n";
 die(); } 
  if($_GET['ListItem']=='ListItem') { 
  function sala($sala) {$trans = array('1' => 'Amigos', '2' => 'Amor', '3' => 'Placer', '4' => 'Mas De 30', '5' => 'Sexo');
echo strtr($sala, $trans); }  
 echo sala($_GET['item'])." 1|"; echo count(glob("../usuarios/".$_GET['item']."/1/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|".$_GET['item']."|1| \n"; 
  echo sala($_GET['item'])." 2|"; echo count(glob("../usuarios/".$_GET['item']."/2/{*,.[!.]*,..?*}",GLOB_BRACE)); echo "|".$_GET['item']."|2| \n";   
 die(); } ?>