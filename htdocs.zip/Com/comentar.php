<head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <script src="../css/event.js?gg=5"> </script> <link rel="stylesheet" type="text/css" href="../Com/files/com.css?tg=4"> </head><body>
<?php  header('Cache-Control: no cache'); 
session_cache_limiter('private_no_expire'); 
session_start(); if (isset($_SESSION['nombre'])) {  ?>
<?php include("files/tiempo.php"); include("files/bbcod.php");  if(file_exists("tmp/".$_GET["id"].".com")) {  ?>
<?php if($_SERVER['REQUEST_METHOD']==='POST') { if($_POST['comento'] !==""){
		
$nick =$_SESSION["nombre"];
$texto = $_POST["comento"];
$texto = str_replace("\r\n"," ",$texto);
$texto =str_replace("|","⎥",$texto);
$timdat = time();
$fp = fopen("tmp/".$_GET['id'].".com", 'a');
fwrite($fp,$nick."|".stripslashes(htmlspecialchars($texto))."|". $timdat."|".PHP_EOL); fclose($fp);
unset($_POST);
  } else { unset($_POST);  echo "<div style='position:fixed;background:red;'>nooo </div>"; } }?>
  
<div class="title">PUBLICACION DE.</div>
<?php $load = file("public.pc");
foreach($load as $loade) { if(strpos($loade,$_GET['id']) !==false) { $rows =explode("|",$loade);  
$data = json_decode(file_get_contents('http://api.rest7.com/v1/detect_nudity.php?url=https://chattoing.ml/Com/img/' . $rows[4]));
if($data->nudity==true) { $imge ="sensure.png"; $bef = "max-height:40%"; } else{ $imge = $rows[4]; }
echo "<title>$rows[1]-Publico</title><div class='ComBody'><div class='ComNick'><img src='".(file_exists('../usuarios/perfil/'.$rows[1].'.png')? '../usuarios/perfil/'.$rows[1].'.png': '../Com/files/onerror.png')."' class='ComFoto'/>  <div style='padding-top:2%'> <b>$rows[1]</b> <br><font style='font-size:12px;color:#888'>".DlnTime($rows[3])."</font></div></div><div style='padding-left:2%;background:$rows[5];'  class='$rows[6]'>".(!empty($rows[6]) || !empty($rows[4])? $rows[2] : bbcod($rows[2]))."</div>"; if(!empty($rows[4])) { list($w, $h)= getimagesize('img/'.$rows[4]); echo "<div style='overflow:hidden;width:100%;height:70%;bef' ><img src='../Com/img/$imge' style='object-fit:cover;width:100%;height:".($w>2000 ? 'auto':'100%').";'/></div>"; }  echo "<br></div><br>";  } }?>
<div style="background:white"> <br><b>Comentarios recientes.</b><div class='cuchillo'><br></div><br/><br/>
<?php $come = file("tmp/".$_GET["id"].".com"); 
$ran =array("Se la primera persona en comentar!","Haz un comentario!","Comenta esta publicación!");
if (filesize("tmp/".$_GET["id"].".com")==0){ echo " <font color='#777'>Nada que leer. <br><br><br>". $ran[array_rand($ran)]."</font>"; } else {
foreach($come as $co) {   $li =explode("|",$co); echo "<img src='".(file_exists('../usuarios/perfil/'.$li[0].'.png')? '../usuarios/perfil/'.$li[0].'.png':'../Com/files/onerror.png')."' class='ComFoto' style='float:left'/><div class='ComComento'><b>$li[0]</b><br> $li[1]<br><font style='color:#777;font-size:10px;float:right'>(".DlnTime($li[2]).")</font></div><br><div class='cuchillo'></div>"; }   }?>

<br/><form method="post" action="../add?id=<?php echo $_GET['id'];?>&goback=1">
<table width="100%"><tr><td width="70%"><textarea name="comento" placeholder="Escribe un comentario" style="color:#666;border:#eaeaea 1px solid;border-radius:1em;width:100%"></textarea>
</td><td width="30%"><input type="submit" value="Publicar"/></form></td></tr></table><br/> </div>
<?php }else { echo "Error";} ?>
<?php } ?> <div style="display:none">