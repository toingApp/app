<?php
function bbcod($text) { 
	$find = array(
		'~\[b\](.*?)\[/b\]~s',
		'~\[i\](.*?)\[/i\]~s',
		'~\[u\](.*?)\[/u\]~s',
		'~\[quote\](.*?)\[/quote\]~s',
		'~\[size=(.*?)\](.*?)\[/size\]~s',
		'~\[color=(.*?)\](.*?)\[/color\]~s',
		'~_(.*?)_~s',
		'~\[img\](https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\[/img\]~s'
	);
	$replace = array(
		'<b>$1</b>',
		'<i>$1</i>',
		'<span style="text-decoration:underline;">$1</span>',
		'<pre>$1</'.'pre>',
		'<span style="font-size:$1px;">$2</span>',
		'<font style="color:$1;">$2</font>',
		'<a href="$1">$1</a>',
		'<img src="$1" alt="" />'
	);
$text = preg_replace($find,$replace,$text);
if(preg_match('%(http[s]?://|)(www\.|m\.|)(youtu|youtube)(\.com|\.be)\/(watch\?v=|)([A-zA-z0-9-]+)%', $text)) { 
$text = preg_replace('%(http[s]?://|)(www\.|m\.|)(youtu|youtube)(\.com|\.be)\/(watch\?v=|)([A-zA-z0-9-]+)%', '<a href="https://youtu.be/\6">youtu.be/\6</a><embed src="https://www.youtube.com/embed/\6?autoplay=1" width="100%" height="50%"></embed>', $text, 1);   
$tex = preg_replace("/\<\/embed\>.*$/", '', $text); } 
elseif(preg_match("#((http[s]?://)(\S*?\.\S*?))(\s|\;|\)|\]|\[|\{|\}|,|”|\"|'|:|\<|$|\.\s)#i", $text, $result))
{ $text = str_replace($result[2].$result[3], "<a href='http://$result[3]'>$result[2]".preg_replace('/\/.*$/','', $result[3])."</a>", $text);
$url = preg_replace('%(www\.|m\.|)(instagram)(\.com)\/([A-zA-z0-9_.-]+\/).*$%', '\1\2\3/\4channel/',$result[3]);
 $url = "http://".$url."";
$doc = new DOMDocument();
$doc->loadHTMLFile($url);
$xpath = new DOMXPath($doc);
$list = $doc->getElementsByTagName("title");
$mo = utf8_decode($list->item(0)->textContent);

$xml = simplexml_import_dom($doc);
if($xml ==null) { $ic ="null"; } else{
 $arr = $xml->xpath('//meta[@property="og:image"]');
 $ic = $arr[0]['content']; 
 $arr2 = $xml->xpath('//meta[@property="og:title"]');
 $des = (string)$arr2[0]['content'];  }
  
$tex = $text."<br/><div style='margin-left:1%;display:flex;flex-flow: row nowrap;align-items: center;background:#eaeaea;width:95%'><div style='width:30%'><img src='$ic' width='85%'/></div><div style='width:70%'><font color='#777'>".preg_replace('/\/.*$/', '', strtoupper($result[3]))."</font><br>".substr($mo,0, 35)."<br>$des</div></div>"; } else{
$tex =  $text; }

return $tex;
}
?>