<?php
  $path = "../../Com/img/".$_GET['path'];
$extension = explode(".",$_GET['path']);

   if($extension[1]=="jpg" || $extension[1] =="jpg") { $dest = @imagecreatefromjpeg($path);  } 
    else if($extension[1]=="gif") {  $dest = @imagecreatefromgif($path);  }
     else {  $dest = @imagecreatefrompng($path);   }
     
   $src = @imagecreatefrompng('../../Com/files/onerror.png');
$w = imagesx($dest);
$y = imagesy($dest);
    // Copy and merge
$img = imagecreatetruecolor($w, $y);
imagecolorallocate($img, 0, 225, 0);
$white = imagecolorallocate($img, 255, 0, 0);
  $font_path = '../../fonts/Blazed.ttf';
  $text = "CENSURADO";
  $tw   = strlen($text) * imagefontwidth(3);
  $th   = imagefontheight(3);

  imagettftext($img, 30, 0,  (imagesx($img) - $tw) / 9, (imagesy($img) - $th) / 2,  $white, $font_path, $text);

imagecopymerge($dest, $img,  0, 0, 0, 0, $w, $y, 93);

header('Content-type: image/png');
            imagepng($dest);
imagedestroy($dest);

?>