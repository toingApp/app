<?php
  function DlnTime($timeStamp) {
    $str_time = date("Y-m-d H:i:s", $timeStamp);
    $time = strtotime($str_time);
    $d = new DateTime($str_time);

    $weekDays = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'S�bado', 'Domingo'];
    $months = ['Enero', 'Febrero', 'Marzo', 'Abril', ' Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

    if ($time > strtotime('-2 minutes')) {
      return 'Justo ahora';
    } elseif ($time > strtotime('-59 minutes')) {
      $min_diff = floor((strtotime('now') - $time) / 60);
      return 'Hace '.$min_diff . ' minuto' . (($min_diff != 1) ? "s" : "") ;
    } elseif ($time > strtotime('-23 hours')) {
      $hour_diff = floor((strtotime('now') - $time) / (60 * 60));
 $dln = new DateTime();
 $dln->setTimestamp($timeStamp);
 $dln2 = new DateTime();
 $dln2->setTimestamp(time());
 $interval = $dln->diff($dln2, true);     
      
      return 'Hace '.$hour_diff . ' hora' . (($hour_diff != 1) ? "s" : "").' '.$interval->format(' con %i min') ;
    } elseif ($time > strtotime('today')) {
      return $d->format('G:i');
    } elseif ($time > strtotime('yesterday')) {
      return 'Ayer a las ' . $d->format('G:i');
    } elseif ($time > strtotime('this week')) {
      return $weekDays[$d->format('N') - 1] . ' a las ' . $d->format('G:i');
    } else {
      return $d->format('j') . ' de ' . $months[$d->format('n') - 1] .
      (($d->format('Y') != date("Y")) ? $d->format(' Y') : "") .
      ' a las ' . $d->format('G:i');
    }
  }


?>