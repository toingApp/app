<html><head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING NEWS</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <script src="../Com/files/motor.js"></script>
 <link rel="stylesheet" type="text/css" href="../Com/files/com.css?ih7j2=lkyj"> </head><body>

<script>
  function like(lik){ $("#"+lik).load("../Com/like.php?id=" +lik, function(response){  var getlik = $("#"+lik).text(); $("#blu"+lik).html("<img src='../Com/files/likeblu.png?4=4' width='5%' height='auto' style='margin-left:3%'/>"+getlik);  }); } function comGo(com){ location.href = '../add?id=' +com;} </script>
  <script>
 var loadFile = function(event) {
 var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  $(".outputdiv").show(); $("textarea").css({"background":"","color":""}); $(".coloor input").val("#ffffff");
  }; function delFil(){ $("#filem").val(null); $(".outputdiv").hide(); } function loadColor(val) { $("textarea").css("background",val); var colortxt =   (parseInt(val.replace('#', ''), 16) > 0xffffff / 2) ? '#000' : '#fff'; $("textarea").css("color",colortxt); delFil();    }
function auto_grow(element) { element.style.height = "20px";  element.style.height = (element.scrollHeight)+"px"; }</script>
<style type='text/css'>#more .com:nth-of-type(9) ~ .com{ display: none;} </style>

<?php  session_start(); if (isset($_SESSION['nombre'])) { ?>
<?php include("../Com/files/tiempo.php");  include("../Com/files/bbcod.php");?>


<?php if (isset($_SESSION['id'])) { ?>
<div class="nav" align="center"><a href="../d"> <div></div> </a><a href="../msg"> <div> <?php
 $string = $_SESSION['nombre'];
 $ms  = glob("../mp/count/*.cnt");
foreach ($ms as $mens) {
if (strpos($mens, "-".$string."-") !== false) { 
$lee = file($mens); 
$dee = $lee[0];
$listo = str_replace($string,"",$dee);
$tu += str_word_count($listo); } }
if($tu > 0){ echo "<font color='red'>".$tu."</font>";} ?> </div> </a><a href="../index.php"> <div></div> </a><a href="../Cuenta/myPerfil.php"> <div></div> </a></div>
<br/><br/><br/>  <?php }else{?>
<div align="center"><a href="../index.php"><img src="../images/home.gif"/>
<img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div> <?php }?>

<div class="gris"><form method="post" action="../Com/post.php" enctype="multipart/form-data">
<table width="100%"><td width="70%"><textarea name="msg" style="width:100%;" oninput="auto_grow(this)" placeholder="Que estas pensando?" autofocus></textarea></td><th width="30%"><input type="submit" value="Publicar" /></th></table><div class="outputdiv"><font style="float:right" onclick="delFil()">✘</font><img id="output"/></div>
<table width="100%" cellpading="0" cellspacing="0" style="border-top:#777 solid 1px"><th width="50%" style="border-right:#777 solid 1px"><label class="upload"></label><label><input type="file" name="file" onchange="loadFile(event)" id="filem" accept="image/*" />╬</label></th><th width="50%"><label class="coloor"><input type="color" name="color" value="#ffffff" onchange="loadColor(this.value)"/></label></th></table>
</form></div>

<div class="more">
<?php 
$fill= file('public.pc');
$arrcount = count($fill); $coma = '"';
foreach (array_slice(array_reverse($fill),0,4, true) as $line_num => $line) {
$zindex = $arrcount - 1 - $line_num;
$lin = explode("|",$line);
if(empty($lin[4])) { } else {$data = json_decode(file_get_contents('https://api.sightengine.com/1.0/nudity.json?api_user=1499544130&api_secret=VKVqCc4ujKsaKbRDeTKS&url=https://chattoing.ml/Com/img/' . $lin[4])); }
if($data->nudity->raw=="0.98") { $imge ="files/censurar.png"; $bef = "max-height:40%"; } else{ $imge = "img/$lin[4]"; } $bf = $data->nudity->raw;
$h = array_reverse(file("tmp/".$lin[0].".com")); $hL =explode("|",$h[0]); 
 echo "<section class='ComBody' update='$line_num'><div class='ComNick'><img src='".(file_exists('../usuarios/perfil/'.$lin[1].'.png')? '../usuarios/perfil/'.$lin[1].'.png': '../Com/files/onerror.png')."' class='ComFoto'/> <div style='padding-top:2%'><b>$lin[1] </b> <br><font style='font-size:12px;color:#888'>".DlnTime($lin[3])."</font></div></div><div style='word-wrap:break-word;padding-left:4%;background:$lin[5];'  class='$lin[6]'>".(!empty($lin[6]) || !empty($lin[4])? $lin[2] : bbcod($lin[2]))."</div>"; if(!empty($lin[4])) { list($w, $h)= getimagesize('img/'.$lin[4]); echo "<div style='overflow:hidden;width:100%;height:70%;$bef' ><img src='../Com/$imge' style='object-fit:cover;width:100%;height:".($w>2000 ? 'auto':'100%').";'/></div>";} echo (count(file('tmp/'.$lin[0].'.lik')) >0 ? '<font id="blu'.$lin[0].'"><img src="../Com/files/likeblu.png?4=5" width="4%" height="auto" style="margin-left:3%"/>'.count(file('tmp/'.$lin[0].'.lik')).'</font>' : '<font id="blu'.$lin[0].'"></font>')."<table width='100%'><td width='50%' align='center'> <div class='botonL' onclick='like(".$coma.$lin[0].$coma.")'><img src='../Com/files/like.png?7=7' width='15%'/>".(count(file('tmp/'.$lin[0].'.lik')) >0 ? '<font id="'.$lin[0].'">'.count(file('tmp/'.$lin[0].'.lik')).'</font>' : '<font id="'.$lin[0].'"></font>')."</div></td><td width='50%' align='center'><div class='botonC' onclick='comGo(".$coma.$lin[0].$coma.")'><img src='../Com/files/com.png?5=5' width='15%'/>".(count(file('tmp/'.$lin[0].'.com')) >0 ? count(file('tmp/'.$lin[0].'.com')) : ' ')."</div></td></table>".(empty($hL[0])?' ':'<div class="cuchillo"></div><div class="ComComento"><b>'.$hL[0].'</b><br/>'.mb_strimwidth($hL[1], 0, 110,"<font color='#777'>...mas</font>").'</div>')."</section>";  } 
?>
</div><div id="loader" align="center" style="display:none;height:10%;position:fixed;width:100%;bottom:0;background:#eaeaea;z-index:2">Cargando...</div>
<script>
	$(window).bind('scroll', function() { 
    if($(window).scrollTop() + window.innerHeight > $(document).height() - 50) { $("#loader").show();
var nums = $('.more .ComBody:last').attr('update');
var num = parseFloat(nums) + parseFloat("1");
var res = $(document.createElement("p")).load('../Com/update.php?updat='+num+' .ComBody');
$('.more').append(res);  $("#loader").fadeOut(5000,);  }
var seen = {};
$('.ComBody').each(function() {
    var txt = $(this).text();
    if (seen[txt])
        $(this).remove();
    else
        seen[txt] = true;
});
}); 
</script>
<sscript src="../css/event.js?nn=hhy"> </sscript> 
<?php } ?> <div style="display:none"></body>