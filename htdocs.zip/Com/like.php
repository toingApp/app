<?php session_start();
$pagina = file_get_contents('../Com/tmp/'.$_GET["id"].".lik");
$pos = strpos($pagina, $_SESSION["nombre"]);
if ($pos === false) {
 $fp = fopen("../Com/tmp/".$_GET["id"].".lik", 'a');
fwrite($fp, $_SESSION['nombre'].PHP_EOL);
fclose($fp); }
 else{}
echo count(file("../Com/tmp/".$_GET["id"].".lik"));
?>