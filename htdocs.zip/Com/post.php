<?php  session_start(); if (isset($_SESSION['nombre'])) { ?>

<?php 
$nick = $_SESSION["nombre"];
$spam = array('%([^A-Z-a-z0-9 ]{100})%','%([A-Z-a-z0-9]{100})%');
$msg = htmlspecialchars(str_replace("|","⎥",$_POST['msg']));
$msg = preg_replace($spam, ' ', $msg);
if (preg_match('/^#[0-9A-F]{6}$/i', $_POST['color'])) { $color = $_POST['color']; }else { $color="#ffffff";}

$id = str_shuffle("56784310");
$timdat = time();  
if($color=="#ffffff") { 
if(preg_match("/\.(gif|png|jpg)$/", $_FILES['file']['name'])) { $ext = "toing_".str_shuffle("ABCD1239054").".".pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
if(move_uploaded_file($_FILES['file']['tmp_name'],"img/".$ext)) { $foto =$ext;} }
} else {if(hexdec(substr($color,1,2)) + hexdec(substr($color, 3,2)) + hexdec(substr($color,5,2)) > 382) { $txtCo = "ComOscuro";} else{ $txtCo ="ComClaro";} }
if(strlen(str_replace(" ","",$_POST['msg'])) >1){
$msg = "$id|$nick| ".str_replace("\r\n",' <br>',$msg)." |$timdat|$foto|$color|$txtCo|";
$fpn = fopen("public.pc", "a");
fwrite($fpn, $msg.PHP_EOL); 
fclose($fpn); header("location: ../d"); fopen("tmp/".$id.".lik","w"); fopen("tmp/". $id.".com","w"); } else{header('Location: ../d');}?>
<?php } ?> <div style="display:none">