 <!DOCTYPE html> <head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING REGISTRO</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <script src="../css/event.js?66=55"> </script>
<link rel="stylesheet" type="text/css" href="../css/event.css?v67yuj=tjuuiy1">
</head><body>
<?php  session_start(); if (isset($_SESSION['id'])) { ?>
   
<?php
header('Location: ../index.php');  ?>
 
<?php } else {  ?>

<div class="header_interno" align="center">
<img src="../images/icono.png" width="15%" alt="Chat toing"/></div>
<div class="titulo">Login</div><br/>

<?php
$usuario = $_POST['Usuario'];
$clave = $_POST['Clave'];
$usuarioreg = '../usuarios/reg/'.$usuario;
$id = str_shuffle("abcdEfgLwhR");

if(isset($_POST['Usuario'])){
if (file_exists($usuarioreg)) {
    $md5cod = md5($clave);
    $cargaruser = file($usuarioreg);
    $clavecod = str_replace("\n", "",$cargaruser[0]);
     if (md5($clave) === $clavecod) {
$_SESSION['nombre'] = $usuario;
$_SESSION['id'] = $id; } 
else {  echo '<font color="red">La Contrasenia es incorrecta</font>';}
    fclose($cargaruser);
} else { echo '<font color="red">El Usuario ingresado no existe</font>';
} } ?>   
    
<div class="gris" align="center">
<form method="post" action="login.php" name="formulario">
Nick:<br/>
<input type="text" name="Usuario"/><br/>
Contrasenia:
<br/><input type="password" name="Clave"/>
<a href="javascript:document.formulario.submit()" ><div class="entrar">Registrar</div></a>  </div> </form> </div>

<br/>
<div class="gris" align="center">
<br/><br/>
<a href="registro.php" style="font-size:small">
Quiero crear un login permanente</a></div>
<?php }?>
<div style="display:none">