<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../css/app.css">
<style>.perfil{color:white;font-size:18px}.perfil img{border-radius:3em;margin:10px}.perfil span{color:white;font-weight:italic;font-size:19px}.perfil div{padding:16px;background:url(../images/nova2.png) no-repeat;background-size:100% 100%;}.perfil img,  .perfil span, .perfil{-webkit-box-shadow: 4px 4px 9px #00f8ff;-moz-box-shadow: 2px 2px 5px blue;text-shadow:1px 1px 1px #00fff0;}</style>


<?php  session_start(); if (isset($_SESSION['id'])) { ?>
<div class="titulo">Mi Perfil</div>

<?php $user = $_SESSION['nombre'];
$color = $_POST['color'];
$error ='"../images/onerror.png"';

if(isset($_POST['name'])){
if(preg_match("/\.(gif|png|jpg)$/", $_FILES['foto']['name'])) {
if(move_uploaded_file($_FILES['foto']['tmp_name'], "../usuarios/perfil/".$user.'.png')) { } }

	if($_POST['name'] != ""){
	$name = htmlspecialchars($_POST['name']);}

	if($_POST['edad'] != ""){
	$edad = htmlspecialchars($_POST['edad']);}
	
		if($_POST['ciudad'] != ""){
	$ciudad = htmlspecialchars($_POST['ciudad']);}

	if($_POST['soy'] != ""){
	$soy = htmlspecialchars($_POST['soy']);}	

	if($_POST['estado'] != ""){
	$estado = htmlspecialchars($_POST['estado']);}	
	
	if($_POST['color'] != ""){
	$color = htmlspecialchars($_POST['color']);}	
  
  $profile_us = file("../usuarios/reg/".$user);
  $xml = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$_SERVER["HTTP_CF_CONNECTING_IP"]);
 
$fp = fopen("../usuarios/perfil/".$profile_us[1].".us", 'w');
fwrite($fp, "$name|$edad|$ciudad|$soy|$estado|$color|".PHP_EOL.$user.PHP_EOL.$xml->geoplugin_countryName); 
fclose($fp); }?>

<?php if($_GET['perfil']=="cambiar") {
$user = $_SESSION['nombre']; 
$profile_us = file("../usuarios/reg/".$user);
$fil = file("../usuarios/perfil/".$profile_us[1].".us"); 
$row = explode("|", $fil[0]); ?>
<form method="post" action="myPerfil.php" name="formulario" enctype="multipart/form-data"> <div class="linea_a"> <input type="file" name="foto"></div>
<div class="linea_b">Nombre: <input type="text" name="name" size="10" value="<? echo $row[0];?>"/></div>
<div class="linea_a">Edad: <input type="text" name="edad" size="4" value="<? echo $row[1];?>"/></div>
<div class="linea_b">Soy: <input type="radio" name="soy" value="Masculino"/>Hombre <input type="radio" name="soy" value="Femenino"/>Mujer</div>
<div class="linea_a">Estado: <select name="estado" size="10"><option value="Soltero(a)">Soltero(a)</option><option value="Casado(a)">Casado(a)<option value="Comprometido(a)">Comprometido(a)</option></select></div>
<div class="linea_b">Fondo: <select name="color" size="10">
<option value="black">Negro</option><option value="#f153ff">Rosado</option><option value="#7500ff">Morado</option>
<option value="#17326a">Azul marino<option value="url(../images/nova.png) center no-repeat;background-size:100% 100%" selected>Defecto</option></select></div>
<div class="linea_a">Ciudad: <input type="text" name="ciudad" size="10" value="<? echo $row[2];?>"/></div>
<a href="javascript:document.formulario.submit()" ><div class="entrar">Guardar</div></a>  </div> </form>

 <?php } else{ 
 $user = $_SESSION['nombre'];
$profile_us = file("../usuarios/reg/".$user);
$file = file("../usuarios/perfil/".$profile_us[1].".us");
$row = explode("|", $file[0]);   ?>
	<style>
		#top {width:100%; height:13%;background:#3C81D8}
		#bottom {width:100%; height:10%}
		#img {position:absolute;margin-top:-18%;width:100%;}
		#img img {background:#eaeaea;border-radius:4em;box-shadow: 1px 1px 2px #000}
      #horizontal {display:flex; align-items: center; justify-content: center;font-size:small}
      #horizontal  div{width:20%;padding:3%;}
      #country{font-size:small;padding-left:5%;}
      #info{box-shadow: 1px 0px 3px #000;width:90%;margin:5%}
      #edit{float:right;margin-right:10%}
</style>
 <div id="top"></div> 
 <div align="center" id="img"><img  width="30%" src="../images/onerror.png"/></div>
 <div id="bottom" align="center"></div>
 <div align="center"><b><? echo $file[1]; ?></b></div>
 <div id="horizontal" align="center"><div><img  width="30%" src="../images/profil_friend.png"/><br/>Amigos</div><div><img  width="30%" src="../images/profil_like.png"/><br/>Me Gusta</div><div><img  width="40%" src="../images/profil_view.png"/><br/>Vistos</div></div>
 <div id="country"><br><img src="../images/profil_location.png" width="5%"/><? echo $file[2]; ?> <a href='myPerfil.php?perfil=cambiar'><img id="edit" width="7%" src="../images/profil_edit.png" /></a></div></div>
<div id="info">43</div>
<?php }?>
<br/><a href="../index.php">Volver</a>
<?php } else{ header('Location: ../Cuenta/login.php'); }?> <div style="display:none">