<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../css/app.css">
<style>.perfil{color:white;font-size:18px;background:black}.perfil img{border-radius:3em;margin:10px}.perfil span{color:white;font-weight:italic;font-size:19px}.perfil div{padding:16px;background:url(../images/nova2.png) no-repeat;background-size:100% 100%;}.perfil img,  .perfil span, .perfil{-webkit-box-shadow: 4px 4px 9px #00f8ff;-moz-box-shadow: 2px 2px 5px blue;text-shadow:1px 1px 1px #00fff0;}</style>


<?php  session_start(); echo "mantenimiento "; die();  if (isset($_SESSION['nombre'])) { ?>
<div align="center"><a href="../index.php"><img src="../images/home.gif"/><img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div>
<div class="titulo">Perfil</div>

<?php  if(file_exists("../usuarios/perfil/".$_GET['Usuario'].".html")) {
$perfil = file("../usuarios/perfil/".$_GET['Usuario'].".html");
foreach($perfil as $perfi) {
echo $perfi; } echo "<br/><a href='../read?de=".$_GET['Usuario']."'>Enviar Mensaje</a>"; }  else { echo "<div class='perfil'>El perfil de <b>".htmlspecialchars($_GET['Usuario'])."</b> no esta actualizado</div>";}?>
<br/> <a href="javascript: history.go(-1)">Volver</a>
<?php } else{ header('Location: ../index.php'); }?> <div style="display:none">