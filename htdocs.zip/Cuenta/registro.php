<?php session_start();
$usuario = $_POST['Usuario'];
$clave = $_POST['Clave'];
$usuarioreg = '../usuarios/reg/'.$usuario;
$usuarioglo = '../usuarios/global/'.$usuario;
$id = str_shuffle("abcdEfgLwhR");
$id_user = str_shuffle("123456780");
$ip = $_SERVER['REMOTE_ADDR'];
$usuario = preg_replace('([^A-Za-z0-9._])', '.', $usuario);

if(isset($_POST['Usuario'])){

if (file_exists($usuarioreg)) {
 $error['UserExist'] = 'El nick elegido ya esta en uso';} 
 
if(file_exists($usuarioglo)) {
$error['UserExist2'] = 'El nick elegido ya esta en uso';} 
 
if (strlen($usuario) < 3){
$error['NickCorto'] = 'El nombre debe ser de como minimo de 4 caracteres';}

if (strlen($usuario) > 20 ){
$error['NickLargo'] = 'El nombre debe ser de como maximo de 21 caracteres';}

if (strlen($clave) < 3){
$error['SinPass'] = 'Debes escribir una contrasenia';}

if(empty($error)) {
  $md5cod = md5($clave);
  $registro =  fopen($usuarioreg,'w');
  fwrite($registro,$md5cod.PHP_EOL.$id_user);
  fclose($registro);
   $ips = fopen("../admin/ip.txt",'a');
  fwrite($ips, $ip." |".$usuario.PHP_EOL); fclose($ips);
  $_SESSION['nombre'] = $usuario;
  $_SESSION['id'] = $id; } }?>

 <!DOCTYPE html> <head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING REGISTRO</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <script src="../css/event.js?gg=5"> </script> <script src="../css/motor.js"></script><link rel="stylesheet" type="text/css" href="../css/event.css">
</head><body>


<?php  session_start(); if (isset($_SESSION['id'])) { ?>
   
<?php 
header('Location: ../index.php'); ?>
 
<?php } else {  ?>
<div class="header_interno" align="center">
<img src="../images/icono.png" width="15%" alt="Chat toing"/></div>
<div class="titulo">Registro de Perfil</div>
<font color="red"><?php 
if($error) {foreach ($error as $advertencia){
echo $advertencia; echo '<br/>'; } } ?> </font>


<form method="post" action="registro.php" name="formulario" align="center">
<div class="linea_a"> Nick:
<input type="text" name="Usuario" size="15"/></div>
<div class="linea_b"> Contrasenia:
<input type="password" name="Clave" size="10"/></div>
<div class="linea_a">
<a href="javascript:document.formulario.submit()" ><div class="entrar">Registrar</div></a>  </div> </form> 
<br/>
<div class="gris" align="center">
<br/><br/>
Ya tienes cuenta? <a href="login.php">
Iniciar session</a></div>
<?php }?>
<div style="display:none">