 <!DOCTYPE html> <head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING REGISTRO</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <sscript src="../css/event.js??ho=595"> </sscript>
<link rel="stylesheet" type="text/css" href="../css/app.css?v67yuj=toi">
</head><body>

<?php session_start();
$usuario = $_POST['Usuario']; 
$usuario = substr($usuario,0,21);
$usuarioglo = '../usuarios/global/'.$usuario;
$usuarioreg = '../usuarios/reg/'.$usuario; 
$usuario = preg_replace('([^A-Za-z0-9._™])', '.', $usuario);
$ip = $_SERVER['REMOTE_ADDR'];
if(isset($_POST['Usuario'])){
  
if (file_exists($usuarioglo)) { $error['NombreExistente'] = 'El nick elegido esta en uso';} 

if (file_exists($usuarioreg)) { $error['UsuarioReg'] = 'El nick elegido ya 
ha sido registrado';} 

if(empty($usuario)) {
$error['nombreVacio'] = 'Debes escribir un nombre de usuario';
}

if (strlen($usuario) < 3){
$error['NickCorto'] = 'El nombre  debe contener 3 caracteres mínimo';
}

if(empty($error))   { $registro =  fopen($usuarioglo,'w'); 
    fwrite($registro); 
    fclose($registro); 
  $ips = fopen("../admin/ip.txt",'a');
  fwrite($ips, $ip." |".$usuario.PHP_EOL); fclose($ips);
    $mensaje = 'El Usuario se registro correctamente'; 
$_SESSION['nombre'] = $usuario;  } } ?> 

<?php if (isset($_SESSION['nombre'])) { ?>
   
<?php $url = $_GET['item']; 
if($_SERVER['HTTP_APP'] == "app") {
header('Loged: success'); } else{
header('Location: ../l?item='.$url); } ?>
 
<?php } else {  ?>
<div class="header_interno" align="center">
<img src="../images/icono.png" width="15%" alt="Chat toing"/></div>
<div class="titulo" align="center"> LOGIN</div>

<font color="red"><?php  $result ="";
if($error) {foreach ($error as $advertencia){ $result =str_replace("\n", " ",$advertencia);
 }  echo array_pop($error);  } 
if($_SERVER['HTTP_APP']=="app") { header('Loged: '.$result); }?> </font>

<div class="gris" align="center">Ingresa tu nick:
<form action="login.php?item=<?php echo $_GET['item'];?>" method="post" name="formulario"> <input type="text" name="Usuario" size="30" maxlength="20"/>
<a href="javascript:document.formulario.submit()" ><div class="entrar">Entrar</div></a> </form> </div>
<br/><br/>

<div class="gris" align="center">
Eres nuevo? <a href="../Cuenta/registro.php">
crear cuenta!</a><br/><br/>
Ya tienes cuenta? <a href="../Cuenta/login.php">iniciar session!</a><br/><br/></div>

<?php } ?>
<div style="display:none">