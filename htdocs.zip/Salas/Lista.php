 <html> <head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING SALAS</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <sscript src="../css/event.js?46=55"> </sscript>
<link rel="stylesheet" type="text/css" href="../css/app.css?v67yuj=iuiy1">
</head><body>
<?php session_start();include "../admin/config.php"; include "../admin/func.ban.php";
checkban($_SERVER['REMOTE_ADDR'],$_SESSION['nombre']);?>
<?php  session_start(); if (isset($_SESSION['nombre'])) { ?>

<?php if($_GET['item']=='1' || $_GET['item']=='2' || $_GET['item']=='3' ||
$_GET['item']=='4' || $_GET['item']=='5') {
$item = $_GET['item']; ?>

<div align="center"><a href="../index.php"><img src="../images/home.gif"/>
<img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div>

<?php function sala($sala) {$trans = array('1' => 'Amigos', '2' => 'Amor', '3' => 'Placer', '4' => 'Mas De 30', '5' => 'Sexo');
echo strtr($sala, $trans); }?> 
<div class="titulo"><? echo sala($_GET['item']);?></div>

<a href="../s?item=<?php echo $_GET['item'];?>&id=1"><div class="lista_sala_vi"><span><?php echo sala($_GET['item']);?> 1</span>
<div class="cant_users">(<?php echo count(glob("../usuarios/".$item."/1/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<?php $ver = count(glob("../usuarios/".$item."/1/{*,.[!.]*,..?*}",GLOB_BRACE));
if($ver > 0) {?>
<a href="../s?item=<?php echo $_GET['item'];?>&id=2"><div class="lista_sala_ve"><span><?php echo sala($_GET['item']);?> 2</span>
<div class="cant_users">(<?php echo count(glob("../usuarios/".$item."/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>
<a href="../index.php"><div class="lista_sala_vi"><span>Volver</span></div></a> <?php } else{
echo ' <a href="../index.php"><div class="lista_sala_ve"><span>Volver</span></div></a> '; }?>

<?php }  ?>
<?php } else { 
header('Location: ../Login/login.php');  }?>
<div style="display:none">