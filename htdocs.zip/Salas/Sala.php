<?php  session_start(); if (isset($_SESSION['nombre'])) { ?>
<?php session_start();include "../admin/config.php"; include "../admin/func.ban.php";
checkban($_SERVER['REMOTE_ADDR'],$_SESSION['nombre']);?>
<?php if($_GET['item']=='1' || $_GET['item']=='2' || $_GET['item']=='3' ||
$_GET['item']=='4' || $_GET['item']=='5') {
if($_GET['id']=='1' || $_GET['id']=='2') { ?>

<?php
include"set.php";
set($_GET['item'],$_GET['id'],$_SESSION['nombre']); ?>

 <head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING CHAT</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
 <sscript src="../css/event.js?gg=87"> </sscript> <script src="../css/motor.js"></script><link rel="stylesheet" type="text/css" href="../css/app.css?tg=i5iyi">
</head><body>
<style type='text/css'>
#antes section:nth-of-type(10) ~ section { display: none;} </style>

<script>
setInterval("ages()",1000);
function ages(){
$("#nuevo").load('../Salas/post.php?item=<?php echo $_GET['item']."&id=".$_GET['id'];?> section'); }
</script>

<script>
setInterval("loa()",1000);
function loa(){

var html = $("#chatbox section");

data =$("#nuevo").html();

if ($(data).length > $(html).length) {

var newdata = $(data).slice($(html).length);

$("#chatbox").prepend(newdata); }  }</script>


<div align="center"><a href="../index.php"><img src="../images/home.gif"/>
<img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div>

<div class="gris"  style="margin:0;border-top:#ad92b4 solid 2px;  border-bottom:#ad92b4 solid 2px; padding:0px;display: flex; justify-content: center;">
<form action="" method="post">
 <table align="center"><tr><td>
 <textarea name="usermsg" id="usermsg" rows="2" placeholder="Escribe tu mensaje"
class="escribir"></textarea>
</td><td><div class="inputWrapper" style="height: 50px; width: 50px;">
<input class="fileInput hidden" type="file" name="arquivo" id="image"/></div></td></tr></table>

<table align="center"><tr><td>
<select id="select" name="para" class="para"><option value="" id="">Para Todos</option><?php
$now = $_SESSION['nombre'];
$dir = "../usuarios/".$_GET['item']."/".$_GET['id']."/";
$hideName = array('.','..',$now);  
$files = scandir($dir);
natcasesort($files);
foreach($files as $archivo) {
 if(!in_array($archivo, $hideName)){ 
 echo "<option value='Para: ' id='".$archivo."' class='".$archivo."'>Para ".$archivo."</option>";
    }   }
?> </select> <input type="checkbox" name="pv" value="none" id="pv"/><span style="font-size:11px">Privado</span> </td><td>

   <input type="button"  onclick="return formSubmit();"  id="btn" value="Enviar" 
 class="enviar_msje"/>
  </td></tr></table></form></div>
 <div class="baner"></div>

<div class="titulo">
#<?php $trans = array('1' => 'Amigos', '2' => 'Amor', '3' => 'Placer', '4' => 'Mas De 30', '5' => 'Sexo');
echo strtr($_GET['item'], $trans);?> 
</div> 
<div id="nuevo" style="display:none"></div>

<div id="chatbox"><font id="antes"><?php
 $item =$_GET['item'];
$id =$_GET['id'];
$user =$_SESSION['nombre'];  
if(file_exists("../Salas/msg".$item."_".$id.".html")) {    
 $lines = array_reverse(file("../Salas/msg".$item."_".$id.".html"));
// DEFINIR USUARIOS AL QUE MOSTRAR PV 1
$des = $user."875"; // << Usuario session fin 1
$c =true;
foreach($lines as $line) { $class =(($c = !$c)?'linea_vi':'linea_ve');
if (strpos($line,$des)) {
// SI TIENE 875 mostrar estas lineas 2
$row = explode("|", $line);
echo "<section class=".$class.">".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
//fin
} else {
// MOSTRAR IGUAL PERO SIN LAS LINEAS R42T03
if(!strstr($line,"R42T03")) {
$row1 = explode("|", $line);
echo "<section class='".$class."'>".(file_exists('../usuarios/reg/'.$row1[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row1[1].'">':' ')."<span>".$row1[1]."</span>: ".(file_exists('../usuarios/reg/'.$row1[1])? '</a>':' ').(!empty($row1[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row1[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row1[2].'">' : ' ')."<span>".$row1[2]."</span> ".(file_exists('../usuarios/reg/'.$row1[2])? '</a>' : ' ')." ".(!empty($row1[3])? '<a href="../Com/img/'.$row1[3].'"><img src="../Com/img/'.$row1[3].'" width="5%" height="auto"/></a>' : ' ').$row1[4]."</section>"; }
} }   }else{ echo "<section class='linea_vi'>No hay mensajes recientes.</section>";}  ?></font></div>

  <script>
    function formSubmit(){
var formData = new FormData();
 var files = $('#image')[0].files[0];
var name = document.getElementById("usermsg").value;
var para = $("#select option:selected").val();
 var privado  = $('input[name=pv]:checked').map(function()
   { return $(this).val(); }).get();
var ids = $('#select option:selected').attr('id');
formData.append('file',files);
formData.append('usermsg',name);
formData.append('para',para);
formData.append('pv',privado);
formData.append('id',ids);
jQuery.ajax({
url: "../Salas/proces.php?item=<?php echo $_GET['item'];?>&id=<?php echo $_GET['id'];?>",
contentType: false,
processData: false,
data: formData,
type: "POST", success:function(data){
$("#myForm").html(data);  $("#usermsg").val("");
$("#select").prop('selectedIndex',0); 
$('input:checkbox').prop('checked', false);
$('#image').val(null);
}, error:function (){}
});   return true; }  </script>

<?php } else{echo "error";} } else{ echo "error";}?>
<?php } else { 
header('Location: ../index.php');}  ?>

<div style="display:none;">