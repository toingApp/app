<?php  session_start(); if (isset($_SESSION['nombre'])) { ?>

<?php if($_GET['item']=='1' || $_GET['item']=='2' || $_GET['item']=='3' ||
$_GET['item']=='4' || $_GET['item']=='5') {
if($_GET['id']=='1' || $_GET['id']=='2' || $_GET['id']=='3' ||
$_GET['id']=='4' || $_GET['id']=='5') { ?>

<?php  $users = $_SESSION['nombre'];
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
   session_unset(); 
    session_destroy();  
unlink("../usuarios/1/1/".$users);
unlink("../usuarios/1/2/".$users);
unlink("../usuarios/2/1/".$users);
unlink("../usuarios/2/2/".$users);
unlink("../usuarios/3/1/".$users);
unlink("../usuarios/3/2/".$users);
unlink("../usuarios/4/1/".$users);
unlink("../usuarios/4/2/".$users);
unlink("../usuarios/5/1/".$users);
unlink("../usuarios/5/2/".$users);
unlink("../usuarios/global/".$users);
 
} $_SESSION['LAST_ACTIVITY'] = time(); 
$trans = array('1' => 'Amigos', '2' => 'Amor', '3' => 'Placer', '4' => 'Mas De 30', '5' => 'Sexo');
$on =fopen("../usuarios/online/".$_SESSION['nombre']."^onl",  "w"); 
fwrite($on, $_SERVER['HTTP_CF_IPCOUNTRY']."|".strtr($_GET['item'], $trans)." > ".$_GET['id']."|".$_SERVER['HTTP_USER_AGENT']."|".$_SERVER['SERVER_PROTOCOL']."|");  ?>
 
<?php $item =$_GET['item'];
      $id =$_GET['id'];
 $lines = file("../Salas/msg".$item."_".$id.".html");
// DEFINIR USUARIOS AL QUE MOSTRAR PV 1
$des = $users."875"; // << Usuario session fin 1
$c =true;
foreach($lines as $line) { $class =(($c = !$c)?'linea_vi':'linea_ve');
if (strpos($line,$des)) {
// SI TIENE 875 mostrar estas lineas 2
$row = explode("|", $line);
echo "<section class='".$class."'>".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
//fin 2
} else {
// MOSTRAR IGUAL PERO SIN LAS LINEAS R42T03
if(!strstr($line,"R42T03")) {
if(!$line) { echo "not||||No hay mensajes recientes|"; }
$row = explode("|", $line);
echo "<section class='".$class."'>".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
}
} }  ?>
 
<?php } }?> <?php }?>