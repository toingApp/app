<?php 
session_start();
if(isset($_SESSION['nombre'])){ ?>

<?php if($_GET['item']=='1' || $_GET['item']=='2' || $_GET['item']=='3' ||
$_GET['item']=='4' || $_GET['item']=='5') {
if($_GET['id']=='1' || $_GET['id']=='2' || $_GET['id']=='3' ||
$_GET['id']=='4' || $_GET['id']=='5') { ?>

<?php 
	$nick = $_SESSION['nombre'];
	$text = $_POST['usermsg'];
	$para = $_POST['para'];
	$id = $_POST['id'];
	$texto = str_replace(PHP_EOL," ",$text);
	$texto = htmlspecialchars(str_replace("|","*",$texto));
	$item =$_GET['item'];
	$ide =$_GET['id'];

if(file_exists("../usuarios/reg/".$nick))
{$link1 = "regYesYou"; }

if(file_exists("../usuarios/reg/".$id))
{$link2 = "regYesFor"; }

if(preg_match("/\.(gif|png|jpg|webp)$/", $_FILES['file']['name'])) { $ext = str_shuffle("aBhds1239054").".".pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
if(move_uploaded_file($_FILES['file']['tmp_name'], "../Com/img/".$ext))
 { $foto = $ext;} }
	
		
	
		if($_POST['pv'] != ""){ 
	if($_POST['usermsg'] !="") {
$fp = fopen("../Salas/msg".$item."_".$ide.".html", 'a');
	fwrite($fp," ".$nick."875 ".$id."875 R42T03 |🔐".$nick."|".$id."|".$foto."|".$texto."|".PHP_EOL);
	fclose($fp); }  }
	 
	
	else { if($_POST['usermsg'] !="") {
	
$fp = fopen("../Salas/msg".$item."_".$ide.".html", 'a');
	fwrite($fp, "nononow|".$nick."|".$id."|".$foto."|".$texto."|".PHP_EOL);
	fclose($fp);} } ?>
	
<?php } } ?>    <?php }?>