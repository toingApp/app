<?php session_start();

function set($item,$id,$users) {

if($item=='1' || $item=='2' || $item=='3' || $item=='4' || $item=='5') {
$a ="../usuarios/".$item."/".$id."/".$users;
fopen("../usuarios/".$item."/".$id."/".$users, w); }

$b = array(
"../usuarios/1/1/".$users,
"../usuarios/1/2/".$users,
"../usuarios/2/1/".$users,
"../usuarios/2/2/".$users,
"../usuarios/3/1/".$users,
"../usuarios/3/2/".$users,
"../usuarios/4/1/".$users,
"../usuarios/4/2/".$users,
"../usuarios/5/1/".$users,
"../usuarios/5/2/".$users
);

foreach($b as $bi) { 
if($bi != $a) {
 unlink($bi); } } } ?>