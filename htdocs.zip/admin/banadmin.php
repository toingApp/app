<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style>body{background:white;margin:0;padding:0;font-family:verdana}
.foter{background:#21242d;border-botom:1px solid white;padding:10px;color:white;margin-bottom:20px}
.alert{background:#eff0a4;color:red;border-radius:1em;border:1px solid #fdff00;padding:10px;margin:5px}
.boton{background:#00a1ee;border-radius:2em;padding:5px;color:white;border:transparent}
.lista{background:linear-gradient(#f4f4f4,#00a9d2,#b3bebe);padding:10px;margin:5;text-shadow:2px 1px 2px black;color:white}
.blok{background:#eaeaea;margin-top:6px;padding:10px} .blok span{float:right;}</style>

<?php session_start();
if($_SESSION['nombre'] == "ALESSIA" || $_SESSION['nombre'] =="Sonic") { ?>
<div class="foter">Panel Control</div>
<?php
include "config.php";
include "func.ban.php";

switch ($_GET['x'])
{ 
default:
listbans();
break;
// si agregamos una direccion mostraremos el formulario
case "add":
// y en caso de que el formulario haya sido enviado crearemos el registro
if ($_POST['add'])
{
$ip = $_POST['ip'];
if (!$ip)
{
echo "<div class='alert'> Debes poner una Ip al menos</div>";
} else{
addban($ip,$_POST['nombre'],$_POST['legnth']);
} }
// otra manera de mostrar el formulario
else
{ 
echo "<div class='lista'>Todo los usuarios registrados</div><div class='alert'>Selecciona un usuario para bloquear</div><form method='post' action='banadmin.php?x=add'>";

$data = [];
$f = fopen("ip.txt", "r");

while (!feof($f)) { 

$data[] = explode("|",fgets($f));}
$arrM = array_reverse($data);
foreach($arrM as $row) {
echo ' <div class="blok"><input type="radio" name="ip" value="'.$row[0].'|'.$row[1].'"/>Nombre: '.$row[1].'</div>';  } fclose($f);

echo "Motivos de bloqueo:<br/><input type='text' name='legnth'><br />";
echo "<input type='submit' name='add' value='Agregar direccion' class='boton'/> </form>";
}
break;
// eliminar una direccion 
case "delete":
if ($_GET['id'])
{
delban($_GET['id']);
}
// show error
else 
{
echo "No has seleccionado ninguna ip para eliminar";
} break; } ?>
<?php }else{ echo "No tienes acceso";}?>