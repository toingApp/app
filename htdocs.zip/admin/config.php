<?php
$host = "remotemysql.com:3306";
$dbuser = "NC8RMYnA8L";
$dbpwd = "hHfY83rRD2";
$db = "NC8RMYnA8L";

$connect = mysql_connect ($host, $dbuser, $dbpwd);
		mysql_select_db($db,$connect);?>