<?php
// func.ban.php
// chequea si la ip esta baneada
function checkban($ip,$nombre)
{ 
// consultas de la base de datos
$q = mysql_query("SELECT * FROM banned WHERE ip = '$ip' LIMIT 1");
$get = mysql_num_rows($q);
$p = mysql_query("SELECT * FROM banned WHERE nombre = '$nombre' LIMIT 1");
$nom = mysql_num_rows($p);
if ($get == "1" || $nom == "1")
{ 
// denegar accesos
$r=mysql_fetch_array($q);
die("<div style='background:#ffa1b1;border:maroon 1px solid;border-radius:1em;padding:10px;margin:5px;position:fixed;top:20%;z-index:4;-webkit-box-shadow: 1px 1px 10px black'><font style='font-size:25px;color:white;float:left;border-radius:5em;background:#ff916a;padding-left:10px;padding-right:10px'>!</font>�ERROR x056!<br/>Has sido baneado del sitio. Motivos:  $r[valor]. Usuario: $r[nombre]</div>");
}
}
// agrega una ip baneada
function addban($ip,$nombre,$legnth)
{
// get current time
list($ips,$nam) = explode('|',$ip);
$time = time();
// insertamos en la base de datos
$insert = mysql_query("INSERT INTO banned (ip,time,valor,nombre) VALUES ('$ips', '$time', '$legnth', '$nam')") or die("Error.<br />".mysql.error()."");
echo "<div class='alert'>La direccion ip $ips, ha sido agregada a la lista.</div>";
}
// elimina un registro de la base de datos
function delban($id)
{
$delete = mysql_query("DELETE FROM banned WHERE id = '$id' LIMIT 1"); echo "<div class='alert'>Eliminado de la lista.</div>";
}
// muestra las direcciones baneadas
function listbans()
{ 
echo "<a href='banadmin.php?x=add'><span class='boton' align='center'>Agregar +</span></a><div class='lista'>Listado de usuarios bloqueados</div>";
// bucle para mostrar todas
$query = mysql_query("SELECT * FROM banned ORDER BY time DESC");
$num = mysql_num_rows($query);
if ($num)
{
while ($r=mysql_fetch_array($query))
{
echo "<div class='blok'>$r[ip] – $r[nombre] – <a href='banadmin.php?x=delete&id=$r[id]'><span class='boton'>Eliminar</span></a></div>";
}  }  } ?>