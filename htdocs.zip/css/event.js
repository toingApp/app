document.addEventListener("DOMContentLoaded", function(event) {
var randImg = [ "../images/trineo_1.gif"];   
var sizs = randImg.length
var r = Math.floor(sizs*Math.random());
draw(randImg[r]);
//setTimeout(function() { 
//var sizs2 = randImg.length
//var r2 = Math.floor(sizs2*Math.random());
// draw2(randImg[r2]);  }, 2000);
var div = document.createElement("div");
div.setAttribute("class", "titulo_H");
div.style.width = "100%";
div.innerHTML = " ";
document.getElementsByClassName("titulo")[0].append(div);
initSnow(); //snow
resize(); //snow
});
var ctx = null;
var x_icon = 0;
var y_icon = 0;
var stepX = 1;
var stepY = 1;
var size_x = 80;
var size_y = 40;
var anim_img = null;

function draw(srcs) {
  anim_img = new Image(size_x, size_y);
  anim_img.onload = function() { setInterval('myAnimation()', 50); }
  anim_img.src =srcs;
  anim_img.style.position = 'absolute';
  anim_img.style.cssFloat = "left";
  document.body.append(anim_img);
}
function myAnimation() {
  if (x_icon < 0 || x_icon > window.innerHeight - size_x) {stepX = -stepX; }
  if (y_icon < 0 || y_icon > window.innerWidth - size_y) {stepY = -stepY; }
  x_icon += stepX;
  y_icon += stepY;
  anim_img.style.top = x_icon + 'px';
  anim_img.style.left = y_icon + 'px';
}

var ctx2 = null;
var x_icon2 = 0;
var y_icon2 = 0;
var stepX2 = 2;
var stepY2 = 2;
var size2_x = 83;
var size2_y = 82;
var anim_img2 = null;

function draw2(srx) {
  anim_img2 = new Image(size2_x, size2_y);
  anim_img2.onload = function() { setInterval('myAnimation2()', 50); }
  anim_img2.src = srx;
  anim_img2.style.position = 'absolute';
  anim_img2.style.cssFloat = "left";
  document.body.append(anim_img2);
}
function myAnimation2() {
  if (x_icon2 < 0 || x_icon2 > window.innerHeight - size2_x) {stepX2 = -stepX2; }
  if (y_icon2 < 0 || y_icon2 > window.innerWidth - size2_y) {stepY2 = -stepY2; }
  x_icon2 += stepX2;
  y_icon2 += stepY2;
  anim_img2.style.top = x_icon2 + 'px';
  anim_img2.style.left = y_icon2 + 'px';
}
var numb = ["1", "2", "0", "4"];
setInterval(function() { 
var siz = numb.length
var s = Math.floor(siz*Math.random());
 stepX2 = parseInt(numb[s]);
stepY2 = parseInt(numb[s]);  }, 9000);

var snowMax = 65;
var snowColor = ["#DDD", "#EEE"];
var snowEntity = "&#x2022;";
var snowSpeed = 0.75;
var snowMinSize = 8;
var snowMaxSize = 24;
var snowRefresh = 50;
var snowStyles = "cursor: default; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; -o-user-select: none; user-select: none;";

var snow = [], 
	pos = [],
	coords = [],
	lefr = [],
	marginBottom,
	marginRight;

function randomise(range) {
	rand = Math.floor(range * Math.random());
	return rand;  }

function initSnow() {
	var snowSize = snowMaxSize - snowMinSize;
	marginBottom = document.body.scrollHeight - 5;
	marginRight = document.body.clientWidth - 15;

	for (i = 0; i <= snowMax; i++) {
		coords[i] = 0;
		lefr[i] = Math.random() * 15;
		pos[i] = 0.03 + Math.random() / 10;
		snow[i] = document.getElementById("flake" + i);
		snow[i].style.fontFamily = "inherit";
		snow[i].size = randomise(snowSize) + snowMinSize;
		snow[i].style.fontSize = snow[i].size + "px";
		snow[i].style.color = snowColor[randomise(snowColor.length)];
		snow[i].style.zIndex = 1000;
		snow[i].sink = snowSpeed * snow[i].size / 5;
		snow[i].posX = randomise(marginRight - snow[i].size);
		snow[i].posY = randomise(2 * marginBottom - marginBottom - 2 * snow[i].size);
		snow[i].style.left = snow[i].posX + "px";
		snow[i].style.top = snow[i].posY + "px";  }
moveSnow();  }

function resize() {
marginBottom = document.body.scrollHeight - 5;
marginRight = document.body.clientWidth - 15; }

function moveSnow() {
for (i = 0; i <= snowMax; i++) {
coords[i] += pos[i];
snow[i].posY += snow[i].sink;
snow[i].style.left = snow[i].posX + lefr[i] * Math.sin(coords[i]) + "px";
snow[i].style.top = snow[i].posY + "px";

if (snow[i].posY >= marginBottom - 2 * snow[i].size || parseInt(snow[i].style.left) > (marginRight - 3 * lefr[i])) {
snow[i].posX = randomise(marginRight - snow[i].size);
snow[i].posY = 0;  } }

setTimeout("moveSnow()", snowRefresh);
 }
for (i = 0; i <= snowMax; i++) {
document.write("<span id='flake" + i + "' style='" + snowStyles + "position:absolute;top:-" + snowMaxSize + "'>" + snowEntity + "</span>");
 }
