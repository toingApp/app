<?php session_start() ;
$users = $_SESSION['nombre'];
unlink("usuarios/1/1/".$users);
unlink("usuarios/1/2/".$users);
unlink("usuarios/2/1/".$users);
unlink("usuarios/2/2/".$users);
unlink("usuarios/3/1/".$users);
unlink("usuarios/3/2/".$users);
unlink("usuarios/4/1/".$users);
unlink("usuarios/4/2/".$users);
unlink("usuarios/global/".$users);
unlink("usuarios/online/".$users."^onl");
unlink("usuarios/5/1/".$users);
unlink("usuarios/5/2/".$users);

session_destroy() ; header('Location: index.php');?>