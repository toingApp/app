<?php
   $dest = @imagecreatefrompng('images/fondo_snow.png');
    $src = @imagecreatefrompng('images/onerror.png');
$w = imagesx($dest);
$y = imagesy($dest);
    // Copy and merge
    imagecopymerge($dest, $src, 0, 0, 0, 0, $w, $y, 80);

 
// Output the image
header('Content-type: image/png');

imagepng($dest);
imagedestroy($dest);
?>