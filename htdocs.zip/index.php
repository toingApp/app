<?php session_start(); ?>
<?php 
include("setear.php"); 
include("antiflood.php"); ?>
<html><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="google-site-verification" content="bg-jkGGCUgTQ4TdNizeeUEYXqkYucnTYxifxnmxOEMg" /> 
<title>CHAT TOING</title><sscript src="css/app.js?imbi=bc"></sscript>
<link rel="stylesheet" type="text/css" href="/css/app.css?tyjy=yj7"> </head> <body>
	
<?php  if (isset($_SESSION['nombre'])) {
 $on =fopen("usuarios/online/".$_SESSION['nombre']."^onl", "w");
 fwrite($on, $_SERVER['HTTP_CF_IPCOUNTRY']."|Inicio|".$_SERVER['HTTP_USER_AGENT']."|".$_SERVER['SERVER_PROTOCOL']."|"); ?> 

<div align="center"><a href="/index.php"><img src="/images/home.gif"/>
<img src="/images/localiza.gif"/> <img src="/images/encuentro.gif"/>
<img src="/images/perfil.gif"/>
<img src="/images/buscar.gif"/></a></div>
<style>@font-face {font-family:fuegoo;src: url(/fonts/ARB.woff) format("truetype");}</style>
<div class="titulo">SALAS</div>

<a href="l?item=4"><div class="lista_sala_vi">
<span>Mas De 30</span>
<div class="cant_users">(<?php echo count(glob("usuarios/4/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/4/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div>
</div></a>

<a href="l?item=3"><div class="lista_sala_ve"><span>Placer</span>
<div class="cant_users">(<?php echo count(glob("usuarios/3/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/3/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="l?item=2"><div class="lista_sala_vi"><span>Amor</span>
<div class="cant_users">(<?php echo count(glob("usuarios/2/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/2/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="l?item=1"><div class="lista_sala_ve"><span>Amigos</span>
<div class="cant_users">(<?php echo count(glob("usuarios/1/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/1/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="l?item=5"><div class="lista_sala_vi"><span>Sexo</span>
<div class="cant_users">(<?php echo count(glob("usuarios/5/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/5/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="sp_hom?estado=list_sp"><div class="lista_sala_ve"><span>*Sala Privada*<img src="images/news.gif" width="15%"/></span></div></a>
<a href="d"><div class="lista_sala_vi"><span>*PUBLICACIONES*</span></div></a>

<?php  if (isset($_SESSION['id'])) { 
echo "<br/><a href='Cuenta/myPerfil.php?perfil=".$_SESSION['nombre']."'>Mi Perfil</a>";}?>
<div class="titulo" style="text-align:left;padding-left:5%">Herramientas</div>
<?php 
foreach (glob("usuarios/online/*^onl",GLOB_BRACE) as $file) {
  if(time() - filectime($file) <  180) { $emp.= $file." "; } }
  $total = count(explode(' ',$emp))-1; ?>
<a href="on.so"><div class="linea_a" style="padding:2%">Usuarios Online (<? echo $total;?>)</div></a>
<a href="exit.php"><div class="linea_b" style="padding:2%">Salir</div></a>
<?php   } else {  ?> 
<div class="header_interno" align="center">
<img src="images/icono.png" width="15%" alt="Chat toing"/></div>
<div class="titulo">SALAS</div>

<a href="Login/login.php?item=4"><div class="lista_sala_vi">
<span>Mas De 30</span>
<div class="cant_users">(<?php echo count(glob("usuarios/4/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/4/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div>
</div></a>

<a href="Login/login.php?item=3"><div class="lista_sala_ve"><span>Placer</span>
<div class="cant_users">(<?php echo count(glob("usuarios/3/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/3/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="Login/login.php?item=2"><div class="lista_sala_vi"><span>Amor</span>
<div class="cant_users">(<?php echo count(glob("usuarios/2/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/2/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="Login/login.php?item=1"><div class="lista_sala_ve"><span>Amigos</span>
<div class="cant_users">(<?php echo count(glob("usuarios/1/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/1/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<a href="Login/login.php?item=5"><div class="lista_sala_vi"><span>Sexo</span>
<div class="cant_users">(<?php echo count(glob("usuarios/5/1/{*,.[!.]*,..?*}",GLOB_BRACE)) + count(glob("usuarios/5/2/{*,.[!.]*,..?*}",GLOB_BRACE));?>)</div> </div></a>

<?php }  ?>
<br/> <div id="help" style="background:#ac8fb3;color:white;text-align:center;width:100%">Chat Toing Mod </div><br/><div align="center">Patched by SayGus.</div><div style="display:none">
   
