<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../mp/files/mp.css">
<script>function scrollDown() {
 document.getElementById('chat').scrollTop =  document.getElementById('chat').scrollHeight
}</script>
<body onload="scrollDown()">

<?php  session_start(); if (isset($_SESSION['id'])) { ?>
<style>.d<?php echo $_SESSION['nombre'];?>d  {padding:1px 1px 10px 15px;position:relative;margin-left:auto;color:#666;font-size:14px;background-color:#c8f0af;border-radius:5px;-webkit-box-shadow: 2px 2px 9px #4761c7;margin-top:10px;}
.d<?php echo $_SESSION['nombre'];?>d :after {content:'';position: absolute;left: 92%;top: 0%; width: 0;height: 0;border-left: 15px solid #c8f0af;border-top: 0px solid transparent;border-bottom: 20px solid transparent;}

.d<?php echo $_GET['de'];?>d {padding:1px 1px 10px 15px;position:relative;color:#666;margin-right:auto;font-size:14px;background:#d9efff;border-radius:5px;-webkit-box-shadow: 2px 2px 9px #a080a8;margin-top:10px;}
.d<?php echo $_GET['de'];?>d :after {content:'';position: absolute;right: 92%;top: 0%; width: 0;height: 0;border-right: 15px solid #d9efff;border-top: 0px solid transparent;border-bottom: 20px solid transparent;} </style>


<?php session_start();
foreach (glob("../mp/tmp/-".$_SESSION['nombre']."-.html") as $file) {
 unlink($file);  }  ?>
<?php session_start();
foreach (glob("../mp/tmp/-".$_SESSION['nombre']."-".$_SESSION['nombre']."-.html") as $file) {
 unlink($file);  }  ?>

				<?php
$fi = glob("{../mp/tmp/-".$_SESSION['nombre']."-".$_GET['de']."-.html,../mp/tmp/-".$_GET['de']."-".$_SESSION['nombre']."-.html}",GLOB_BRACE);	
		if (count($fi) > 0){ $fp = $fi[0]; 
$fu = file($fp);
echo "<div class='titulo'><table width='100%'><tr><td width='8%'><a href='../msg'>&#8592;</a></td><td width='10%'><img src='../usuarios/perfil/".$_GET['de'].".png' class='img2'/></td><td>".$_GET['de']."</td></tr></table></div><div class='chat' id='chat''>";
 readfile($fp);?>

<?php if(file_exists("../usuarios/reg/".$_GET['de'])) {
if(isset($_POST['msg'])){
$yo = $_SESSION['nombre'];
$para = $_GET['de'];
$msg = $_POST['msg'];
$msg = str_replace(PHP_EOL," ",$msg);
$ab = fopen($fp, 'a');
fwrite($ab, "<div width='100%' style='display:flex;padding-right:20px;padding-left:10px'> <span class='d".$yo."d'><b>".$yo."</b>: <br/>".stripslashes(htmlspecialchars($msg))."</span></div>".PHP_EOL); fclose($abri);
$cout = basename($fp,".html");
$count = fopen("../mp/count/".$cout.".cnt",'a'); 
fwrite($count,$yo." "); fclose($count);

header('Location: ../read?de='.$_GET['de']);} }?>

<?php $cout = basename($fp,".html");
$con = file("../mp/count/".$cout.".cnt");
$bor = str_replace($_GET['de'],"",$con[0]);
$count = fopen("../mp/count/".$cout.".cnt",'w'); 
fwrite($count,$bor); fclose($count);?>

<?php }else { echo "Sin mensajes que leer. Crea una nueva conversacion!!";?>

<?php 
if(file_exists("../usuarios/reg/".$_GET['de'])) {
if(isset($_POST['msg'])){
$yo = $_SESSION['nombre'];
$para = $_GET['de'];
$msg = $_POST['msg'];
$msg = str_replace(PHP_EOL," ",$msg);
 $abrir = fopen("../mp/tmp/-".$_SESSION['nombre']."-".$_GET['de']."-.html", 'a');
 fwrite($abrir, "<div width='100%' style='display:flex;padding-right:20px;padding-left:10px'><span class='d".$yo."d'><b>".$yo."</b>: <br/>".stripslashes(htmlspecialchars($msg))."</span></div>".PHP_EOL); 
 fclose($abrir);
$count = fopen("../mp/count/-".$_SESSION['nombre']."-".$_GET['de']."-.cnt",'a'); 
fwrite($count,$yo." "); fclose($count);
header('Location: ../read?de='.$_GET['de']); }}   }?>


</div><font id="jump"></font><div class="form"><form method="post" action="../read?de=<?php echo $_GET['de'];?>">
<table widh="100%"><tr><td width="80%" class="formtd"><textarea name="msg" placeholder="Escribe un mensaje"></textarea>
</td><td>
<input type="submit" value="enviar"/></td></tr></table></form> </div>
<?php } else{ header('Location: ../index.php');}?> <div style="display:none">