<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../mp/files/mp.css">

<?php  session_start(); if (isset($_SESSION['id'])) { ?>
<div class="nav" align="center"><a href="../d"> <div></div> </a><a href="../msg"> <div> <?php
 $string = $_SESSION['nombre'];
 $ms  = glob("../mp/count/*.cnt");
foreach ($ms as $mens) {
if (strpos($mens, "-".$string."-") !== false) { 
$lee = file($mens); 
$dee = $lee[0];
$listo = str_replace($string,"",$dee);
$tu += str_word_count($listo); } }
if($tu > 0){ echo "<font color='red'>".$tu."</font>";} ?> </div> </a><a href="../index.php"> <div></div> </a><a href="../Cuenta/myPerfil.php"> <div></div> </a></div>
<br/><br/><br/>
<?php
 $string = $_SESSION['nombre'];
   $fil = glob("../mp/tmp/*.html");
   //mostrar por fecha
$fil = array_combine($fil, array_map("filemtime", $fil));
arsort($fil);

foreach (array_keys($fil) as $file) {
    
if (strpos($file, "-".$string."-") !== false) {
$dee = array_reverse(file($file));
$de = str_replace("<b>".$string."</b>","<b>Tu</b>",$dee);
$de = str_replace("<br/>","",$de);
$di = basename($file,".html");
$count = file("../mp/count/".$di.".cnt");
$di = str_replace($string,"",$di);
$di = str_replace("-","",$di);

echo"<a href='../read?de=".$di."'><table width='100%' class='lista'><tr><td width='15%'><img class='img' src='../usuarios/perfil/".$di.".png'/></td><td  style='border-bottom:1px solid #eaeaea;'><table width='100%'><tr><td align='right'><font class='font'>".substr($di,0,7)."</font>".date('d/m h:i a',filectime($file))." <font class='count'>".substr_count($count[0], $di)."</font></tr><tr><td><div class='buzon'>"; echo $de[0]; echo "</div></td></tr></table></tr></td></table></a>";
    }
} ?>
<?php } else{header('Location: ../index.php');}?><div style="display:none">
