<html><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="google-site-verification" content="bg-jkGGCUgTQ4TdNizeeUEYXqkYucnTYxifxnmxOEMg" /> 
<title>CHAT TOING</title><sscript src="css/app.js?imbi=bc"></sscript>
<link rel="stylesheet" type="text/css" href="/css/app.css?tyjy=yj7"> </head> <body>
<div align="center"><a href="/index.php"><img src="/images/home.gif"/>
<img src="/images/localiza.gif"/> <img src="/images/encuentro.gif"/>
<img src="/images/perfil.gif"/>
<img src="/images/buscar.gif"/></a></div>
<div class="titulo">Usuarios activos</div>

<?php  session_start();
 if (isset($_SESSION['nombre'])) {

 $on =fopen("usuarios/online/".$_SESSION['nombre']."^onl", "w");
 fwrite($on, $_SERVER['HTTP_CF_IPCOUNTRY']."|Online user|".$_SERVER['HTTP_USER_AGENT']."|".$_SERVER['SERVER_PROTOCOL']."|"); }
 
 $c = true;
foreach (glob("usuarios/online/*^onl",GLOB_BRACE) as $file) {
  if(time() - filectime($file) <  180) { $emp.= $file." ";
  $class =(($c = !$c)?'linea_b':'linea_a');
  $fil = file($file);
  $row = explode("|", $fil[0]);
  $de = explode(")", $row[2]);
  $dev = explode(";", $de[0]);
  if(stripos($dev[1], "andr") !==false) { $agent = "<img src='images/agent_android.png' width='7%' style='vertical-align: middle'/>"; }
  if(stripos($dev[1], "ipho") !==false) { $agent = "<img src='images/agent_iphone.png' width='7%' style='vertical-align: middle'/>"; }
  if(stripos($dev[1], "Win") !==false) { $agent = "<img src='images/agent_window.png' width='10%' style='vertical-align: middle'/>"; }
 echo "<div class='$class' style='padding:5%'>".(file_exists('usuarios/reg/'.basename($file, '^onl'))? '<a href="../Cuenta/perfil.php?Usuario='.basename($file, '^onl').'">'.basename($file, '^onl').'</a>' : ' '.basename($file, '^onl').' ')."  <img src='https://www.countryflags.io/$row[0]/flat/24.png' style='vertical-align: middle'/> ".(FALSE === strpos($dev[2], 'SM-') ? $dev[2] : 'Samsung')."  $agent<br/>".($row[3]=='HTTP/1.0' ? ' Protocolo de conexion 1.0': 'Protocolo  de conexion desconocido')."<br/>Status.. $row[1]  <br/><font color='#40B142' style='vertical-align: middle'>online</font></div>";   }  } 
 if(trim($emp)=="") { $total="0"; } else{$total = count(explode(' ',$emp))-1; }
echo "<div class='linea_a' style='padding:3%;margin-top:3%'>Usuarios en linea <font style='float:right'>(".$total.")</font></div>"; ?>

<?php
$output=shell_exec('hello.py');
echo "<pre>$output</pre>";
?>