<?php
foreach (glob("Salas/*.html") as $file) {
if(time() - filectime($file) > 1900){
 unlink($file);  } } ?>

<?php
$folders = [ 'usuarios/1/1/{,.}*', 'usuarios/1/2/{,.}*', 'usuarios/2/1/{,.}*', 'usuarios/2/2/{,.}*', 'usuarios/3/1/{,.}*',   'usuarios/3/2/{,.}*','usuarios/4/1/{,.}*', 'usuarios/4/2/{,.}*', 'usuarios/5/1/{,.}*','usuarios/5/2/{,.}*'];
foreach($folders as $folder) {
 $files = glob($folder, GLOB_BRACE); 
  foreach($files as $file){ 
if(time() - filectime($file) > 1200){
 unlink($file);  } } } ?>


<?php
foreach (glob("usuarios/global/{,.}*",GLOB_BRACE) as $file) {
if(time() - filectime($file) > 172800){
 unlink($file);  } } ?>