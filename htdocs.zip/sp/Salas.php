<?php session_start(); include("../setear.php"); 
?>
<html><head> <meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TOING CHAT</title>
<meta name="description" content="Chat Toing  chat.toing.com"/>
  <sscript src="../css/event.js?nnn=vh5"> </sscript>  <script src="../css/motor.js"></script><link rel="stylesheet" type="text/css" href="../sp/app.css">
</head><body>
<div align="center"><a href="../index.php"><img src="../images/home.gif"/>
<img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div>
<?php if (isset($_SESSION['nombre'])) { ?>
	
<?php if($_GET['id_sala'] == $_SESSION['sala_id'] ) {
$myAdmin =true; $checkPv =true; } ?>
<?php $file = file("tmp/".$_GET['id_sala'].".sp");
$fil = explode("|", $file[0]);  $row = explode("^", $fil[7]);
 $exist = file("tmp/".$_GET['id_sala'].".us", FILE_IGNORE_NEW_LINES);
foreach($exist as $es) { $exp = explode("|", $es); $existe .=$exp[0].","; }
if($fil[2]=="privada") { ?>
	
 <?php
if($checkPv==true) { } else{ if(in_array($_SESSION['nombre'] , explode(",", $existe)) || $_GET['code_sp']==$fil[6]) { $checkPv = true;  } else{ if($_GET['check'] =="check") { $err ="Codigo erróneo"; } echo "<br><div class='titulo'>Sala Privada</div><font color='red'>La sala es privada solicite invitación<br> $err</font><br> <br><div class='blanco'>ingrese código de invitación<br><form action='../sp_sala' method='get' name='formulario'><input type='hidden' name='id_sala' value='$fil[3]'/><span align='center' style='border-bottom:1px solid #555;padding-top:2%'><img src='../sp/code_request.png?4=4' style='width:10%;margin-right:2%'/> <input placeholder='*******' type='number' width='2' style='outline: none;border:none;background:transparent;width:30%' name='code_sp'/></span><a href='javascript:document.formulario.submit()' ><div class='entrar'>Entrar</div></a><input type='hidden' name='check' value='check'/></form></div>"; }  }?>
	
<?php } else{  $checkPb = true; }?>

<?php if($checkPv==true || $checkPb==true) { 
if(in_array($_SESSION['nombre'] , explode(",",$existe))) {  } else{
$fps = fopen("tmp/".$_GET['id_sala'].".us", "a");
fwrite($fps, $_SESSION['nombre']."|".time()."|".PHP_EOL);  } 
foreach(file("tmp/".$_GET['id_sala'].".us") as $del) { $dEx = explode("|", $del);  if($dEx[1] > time() - 60*5) { $dele .= $dEx[0]."|".$dEx[1]."|".PHP_EOL; }   } 
$fp = fopen("tmp/".$_GET['id_sala'].".us", "w"); fwrite($fp, $dele);  ?>
	<script>
setInterval("ages()",1000);
function ages(){
$("#nuevo").load('../sp/post.php?id_sala=<?php echo $_GET['id_sala'];?> section'); }
setInterval("loa()",1000);
function  loa(){
var html = $("#chatbox section");
data =$("#nuevo").html();
if ($(data).length > $(html).length) {
var newdata = $(data).slice($(html).length);
$("#chatbox").prepend(newdata); }  } </script>

<?php if(empty($fil[7])) { echo "<link rel='stylesheet' type='text/css' href='../css/app.css'>"; } else { ?>
<?php $styl = explode("^", $fil[7]);
if(hexdec(substr($styl[2],1,2)) + hexdec(substr($styl[2], 3,2)) + hexdec(substr($styl[2],5,2)) > 382) { $txtCo_vi = "#000000";} else{ $txtCo_vi ="#ffffff";}
if(hexdec(substr($styl[4],1,2)) + hexdec(substr($styl[4], 3,2)) + hexdec(substr($styl[4],5,2)) > 382) { $txtCo_ve = "#000000";} else{ $txtCo_ve ="#ffffff";}
if(hexdec(substr($styl[9],1,2)) + hexdec(substr($styl[9], 3,2)) + hexdec(substr($styl[9],5,2)) > 382) { $txtCo_boton = "#000000";} else{ $txtCo_boton ="#ffffff";}
$linbg_vi = hexdec(substr($styl[2],1,2)) ."," .hexdec(substr($styl[2],3,2)) ."," .hexdec(substr($styl[2],5,2)); 
$linbg_ve = hexdec(substr($styl[4],1,2)) ."," .hexdec(substr($styl[4],3,2)). "," .hexdec(substr($styl[4],5,2));
$form = hexdec(substr($styl[8],1,2)) ."," .hexdec(substr($styl[8],3,2)). "," .hexdec(substr($styl[8],5,2)); ?>
<style>body { background:url(../sp/tmp/<?php echo $fil[8];?>);margin: 0px;font-family:Arial;}
.box{top:-10px;position:relative;width:11%;height:5%;float:left;margin-right:1%}
.box1_vi{position:relative;width:80%;height:70%;border-radius:5px;background:<? echo $styl[3];?>}
.box2_vi{top:-15;left:15px;position:relative;width:60%;height:60%;border-radius:5px;background:white;z-index:1}
.box1_vi:after{content:'';position: absolute;left:12%;top: 70%; width: 0;height: 0;border-right: 15px solid transparent;border-top: 13px solid <? echo $styl[3];?>;border-bottom: 0px solid transparent} 
.box2_vi:after{content:'';position: absolute;left:12%;top: 70%; width: 0;height: 0;border-left: 15px solid transparent;border-top: 13px solid white;border-bottom: 0px solid transparent} 
.box1_ve{position:relative;width:80%;height:70%;border-radius:5px;background:<? echo $styl[5];?>}
.box2_ve{top:-15;left:15px;position:relative;width:60%;height:60%;border-radius:5px;background:white;z-index:1}
.box1_ve:after{content:'';position: absolute;left:12%;top: 70%; width: 0;height: 0;border-right: 15px solid transparent;border-top: 13px solid <? echo $styl[5];?>;border-bottom: 0px solid transparent} 
.box2_ve:after{content:'';position: absolute;left:12%;top: 70%; width: 0;height: 0;border-left: 15px solid transparent;border-top: 13px solid white;border-bottom: 0px solid transparent} 
.linea_ve, .linea_vi {padding:17px 0 4px 5px;} .linea_vi span{color:<? echo $styl[3];?>} .linea_ve span{color:<? echo $styl[5];?>}
.titulo{background:<? echo $styl[0];?>;color:<? echo $styl[1];?>}.linea_vi{background-color:rgba(<?echo $linbg_vi.",0.".$styl[6];?>);color:<? echo $txtCo_vi;?>} .linea_ve{background-color:rgba(<?echo $linbg_ve.",0.".$styl[7];?>);color:<?echo $txtCo_ve;?>} 
.gris {background-color:rgba(<? echo $form.",0.".$styl[10]; ?>)} .enviar_msje{background:<? echo $styl[9]; ?>;color:<? echo $txtCo_boton; ?>} </style>
<?php } ?>
	
<div class="gris"  style="margin:0;border-top:#ad92b4 solid 2px;  border-bottom:#ad92b4 solid 2px; padding:0px;">
<form action="" method="post">
 <table align="center"><tr><td>
 <textarea name="usermsg" id="usermsg" rows="2" placeholder="Escribe tu mensaje"
class="escribir"></textarea>
</td><td><div class="inputWrapper" style="height: 50px; width: 50px;">
<input class="fileInput hidden" type="file" name="arquivo" id="image"/></div></td></tr></table>
<table align="center"><tr><td>
<?php echo '<select id="select" name="para" class="para"><option value="">Para Todos</option>';
foreach(file("tmp/".$_GET['id_sala'].".us") as $rowE) {
if(!strstr($rowE, $_SESSION['nombre'])) { $rw = explode("|", $rowE); echo "<option  value='".$rw[0]."'>Para ".$rw[0]."</option>";   } }
 echo "</select>"; ?>
  <input type="checkbox" name="pv" value="none" id="pv"/><span style="font-size:11px">Privado</span> </td><td>
 <input type="button"  onclick="return formSubmit();"  id="btn" value="Enviar" 
 class="enviar_msje"/>
  </td></tr></table></form></div>
 <?php if($myAdmin ==true) {  echo "<div class='blanco'>Administrador: $fil[1] <br>".(empty($fil[2])? 'Sala público':'Codigo de invitación: '.$fil[6])."</div>";  ?>
 <script> function openC(c) { $(".admin-content").show(); $(c).hide();  } </script>
<input type="button" onclick="openC(this)" value="Abrir"/><div class="admin-content" style="display:none;background:rgba(000, 000, 000, 0.6)"> 
<form method="post" action="../sp/setting.php?color=update&id_sala=<?php echo $_GET['id_sala']; ?>" enctype="multipart/form-data">
<div class="linea_a" style="padding:3%">Fondo: <br> <input type="file" name="file"/></div>
<div class="linea_a" style="padding:3%">Titulo: <br>Color Fondo <input type="color" name="fondo-titulo" value="<?php echo $row[0];?>"/>  | Color Texto <input type="color" name="color-titulo" value="<? echo $row[1];?>"/></div>
<div class="linea_b" style="padding:3%">Linea A: <br>Color Fondo <input type="color" name="fondo-lineaA" value="<? echo $row[2];?>"/>  | Color Texto <input type="color" name="color-lineaA" value="<? echo $row[3];?>"/><br>Opacidad: <input type="range" value="<? echo $styl[6];?>" name="rang_vi" min="0" max="9"  oninput="rangVi.innerHTML= this.value;"/><font id="rangVi"></font></div>
<div class="linea_a" style="padding:3%">Linea B: <br>Color Fondo <input type="color" name="fondo-lineaB" value="<? echo $row[4];?>"/>  | Color Texto <input type="color" name="color-lineaB" value="<? echo $row[5];?>"/><br>Opacidad: <input type="range" value="<? echo $styl[7];?>" name="rang_ve" min="0" max="9"  oninput="rangVe.innerHTML= this.value;"/><font id="rangVe"></font></div> 
<div class="linea_b" style="padding:3%">Entrada de texto: <br>Color Fondo <input type="color" name="fondo-form" value="<? echo $row[8];?>"/>  | Color Boton <input type="color" name="fondo-boton" value="<? echo $row[9];?>"/><br>Opacidad: <input type="range" value="<? echo $styl[10];?>" name="rang_form" min="0" max="9"  oninput="rangForm.innerHTML= this.value;"/><font id="rangForm"></font></div> <div class="linea_a" align="center"><input type="submit" value="Guardar" class="enviar_msje"/></div></form></div>
<?php }?>
	
<div class="baner"></div>
 <div class="titulo"># <?php echo $fil[0];?> </div>
 <div id="nuevo" style="display:none"></div>

<div id="chatbox"><font id="antes"><?php
 $item =$_GET['item'];
$id =$_GET['id'];
$user =$_SESSION['nombre'];  
if(file_exists("../sp/tmp/".$_GET['id_sala'].".box")) {    
 $lines = array_reverse(file("../sp/tmp/".$_GET['id_sala'].".box"));
// DEFINIR USUARIOS AL QUE MOSTRAR PV 1
$des = $user."875"; // << Usuario session fin 1
$c =true;
foreach($lines as $line) { $class =(($c = !$c)?'vi':'ve');
if (strpos($line,$des)) {
// SI TIENE 875 mostrar estas lineas 2
$row = explode("|", $line);
echo "<section class='linea_".$class."'><div class='box'><div class='box1_$class'></div> <div class='box2_$class'></div></div>".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
//fin
} else {
// MOSTRAR IGUAL PERO SIN LAS LINEAS R42T03
if(!strstr($line,"R42T03")) {
$row1 = explode("|", $line);
echo "<section class='linea_".$class."'><div class='box'><div class='box1_$class'></div> <div class='box2_$class'></div></div>".(file_exists('../usuarios/reg/'.$row1[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row1[1].'">':' ')."<span>".$row1[1]."</span>: ".(file_exists('../usuarios/reg/'.$row1[1])? '</a>':' ').(!empty($row1[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row1[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row1[2].'">' : ' ')."<span>".$row1[2]."</span> ".(file_exists('../usuarios/reg/'.$row1[2])? '</a>' : ' ')." ".(!empty($row1[3])? '<a href="../Com/img/'.$row1[3].'"><img src="../Com/img/'.$row1[3].'" width="5%" height="auto"/></a>' : ' ').$row1[4]."</section>"; }
} }   }else{ echo "<section class='li_vi'>No hay mensajes recientes.</section>";}  ?></font></div>

  <script>
    function formSubmit(){
var formData = new FormData();
 var files = $('#image')[0].files[0];
var msg = document.getElementById("usermsg").value;
var para = $("#select option:selected").val();
var privado  = $('input[name=pv]:checked').map(function()
   { return $(this).val(); }).get();

formData.append('file',files);
formData.append('usermsg',msg);
formData.append('para',para);
formData.append('pv',privado);
jQuery.ajax({
url: "../sp/proces.php?id_sala=<?php echo $_GET['id_sala'];?>",
contentType: false,
processData: false,
data: formData,
type: "POST", success:function(data){
$("#myForm").html(data);  $("#usermsg").val("");
$("#select").prop('selectedIndex',0); 
$('input:checkbox').prop('checked', false);
$('#image').val(null);
}, error:function (){}
});   return true; }  </script>
 <?php
} ?>
	
<?php }else{  header('Location: ../Login/login.php'); } ?>
<div style="display:none">