<?php session_start(); include("../setear.php"); 
?>
<html><head> 
<meta name="viewport" content="width=device-width, initial-scale=1.0, 
minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="google-site-verification" content="bg-jkGGCUgTQ4TdNizeeUEYXqkYucnTYxifxnmxOEMg" /> 
<title>CHAT TOING</title>
 <sscript src="../css/event.js?nnn=vh5"> </sscript> <link rel="stylesheet" type="text/css" href="../css/app.css?tg=jytyi">
</head> <body>
<style>.lista_sala_nom{font-size:17px; font-weight:bold} .lista_sala_vio{color:black;margin-top:1%;background:#eaeaea;max-width:100%;padding:5%;position:relative;} .lista_sala_ver{margin-top:1%;color:black;background:#f4f4f4;max-width:100%;padding:5%;position:relative;}</style> 
<div align="center"><a href="../index.php"><img src="../images/home.gif"/>
<img src="../images/localiza.gif"/> <img src="../images/encuentro.gif"/>
<img src="../images/perfil.gif"/>
<img src="../images/buscar.gif"/></a></div>
<?php if (isset($_SESSION['nombre'])) { ?>
	
<?php  if($_GET['estado']=="list_sp") {
echo '<div class="titulo">Salas Privadas</div>';
array_multisort(array_map('filemtime', ($viewF =  glob("tmp/*.sp", GLOB_BRACE))), SORT_DESC, $viewF); $c = true;
foreach($viewF as $viewR) {
$class =(($c = !$c)?'lista_sala_vio':'lista_sala_ver');
$readF = file($viewR);
$rowE = explode("|",$readF[0]);
echo "<a href='../sp_sala?id_sala=".$rowE[3]."&'><div class='".$class."' ".(empty($rowE[8])? '>' : 'style="background:linear-gradient(to left, rgba(255,255,255,0) 10%, rgba(255,255,255,1)), url(../sp/tmp/'.$rowE[8].') left/cover">')." <div><span class='lista_sala_nom'>".$rowE[0]."</span> <span style='float:right;padding-right:10px'>(".count(file('tmp/'.$rowE[3].'.us')).")</span></div> <div><font style='color:#555;font-size:small'>Desc.</font>".$rowE[5]."</div><small>Creado por </small> ".$rowE[1].", <small>".date('d/m/y H:i',$rowE[4])."</small> ".($rowE[2]=='privada'? '<img src="../sp/s_privada.png?4" width="5%"/>': '<img src="../sp/s_publica.png" width="5%"/>')."</div></a>"; }
echo "</div><br><a href='../sp_hom?estado=crea_sp'><div class='linea_a' style='padding: 2% 0 2% 5%;color:#b080c8'>*Crear mi sala*</div></a><br>";  } ?>

<?php if($_GET['estado']=="crea_sp") { 
if(file_exists("tmp/".$_SESSION['sala_id'].".sp"))
{ $sp_exist = "Ya tienes  una sala actual "; } else{ 
$nom_sp = htmlspecialchars(str_replace("|","*",$_POST['nom_sp']));
$desc_sp = htmlspecialchars(str_replace("|","*",$_POST['desc_sp']));
$autor_sp = $_SESSION['nombre'];
$fecha_sp = time();
$privada_sp = $_POST['privada_sp'];
$id_sp = str_shuffle("1234567890");
if($privada_sp=="1") { $privada_sp ="privada"; }else{ $privada_sp ="publica"; }
if(isset($_POST['nom_sp'])){
if (strlen($nom_sp) < 3){ $err = "Nombre demasiado corto."; } else{
$fpsp = fopen("tmp/".$id_sp.".sp", "w");
$fpus = fopen("tmp/".$id_sp.".us", "w");
fwrite($fpsp, substr($nom_sp, 0, 21)."|".$autor_sp."|".$privada_sp."|".$id_sp."|".$fecha_sp."|".substr($desc_sp, 0, 21)."|".str_shuffle('987654301')."|");
$_SESSION['sala_id'] = $id_sp;
fclose($fpsp); header('Location: ../sp_sala?id_sala='.$id_sp);
 } }  } ?>
<div class="titulo">Crear Sala</div><div id="err" style="color:red"><?php echo $sp_exist; echo $err;?></div>
<form method="post" action="../sp_hom?estado=crea_sp" name="formulario">
<div class="linea_a" style="padding: 2% 0 2% 5%">Nombre de la sala (*):<br><input type="text" name="nom_sp"/></div>
<div class="linea_b" style="padding: 2% 0 2% 5%">Descripción (opcional):<br><input type="text" name="desc_sp"/></div>
<div class="linea_a" style="padding: 2% 0 2% 5%">Privada (?):<input type="checkbox" name="privada_sp" value="1"/></div>
<div class="linea_b" style="padding: 2% 0 2% 0"><a href="javascript:document.formulario.submit()" ><div class="entrar">Crear</div></a></div> </form>
<a href='../sp_hom?estado=list_sp'><div class="linea_a" style="padding: 2% 0 2% 5%;color:#a080a8">Regresar</div></a>
<script>if (window.performance && window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD) {
history.back(-1); } </script>
<?php  }?>
	<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
<?php }else{  header('Location: ../Login/login.php'); } ?>
<div style="display:none">
