<?php  session_start(); 
$users = $_SESSION['nombre'];
 $item =$_GET['id_sala'];
 $lines = file("../sp/tmp/".$item.".box");
// DEFINIR USUARIOS AL QUE MOSTRAR PV 1
$des = $users."875"; // << Usuario session fin 1
$c =true;
foreach($lines as $line) { $class =(($c = !$c)?'vi':'ve');
if (strpos($line,$des)) {
// SI TIENE 875 mostrar estas lineas 2
$row = explode("|", $line);
echo "<section class='linea_".$class."'><div class='box'><div class='box1_$class'></div> <div class='box2_$class'></div></div>".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
//fin 2
} else {
// MOSTRAR IGUAL PERO SIN LAS LINEAS R42T03
if(!strstr($line,"R42T03")) {
if(!$line) { echo "not||||No hay mensajes recientes|"; }
$row = explode("|", $line);
echo "<section class='linea_".$class."'><div class='box'><div class='box1_$class'></div> <div class='box2_$class'></div></div>".(file_exists('../usuarios/reg/'.$row[1])? '<a href="../Cuenta/perfil.php?Usuario='.$row[1].'">':' ')."<span>".$row[1]."</span>: ".(file_exists('../usuarios/reg/'.$row[1])? '</a>':' ').(!empty($row[2])? 'para' : ' ').(file_exists('../usuarios/reg/'.$row[2])? '<a href="../Cuenta/perfil.php?Usuario='.$row[2].'">' : ' ')."<span>".$row[2]."</span> ".(file_exists('../usuarios/reg/'.$row[2])? '</a>' : ' ')." ".(!empty($row[3])? '<a href="../Com/img/'.$row[3].'"><img src="../Com/img/'.$row[3].'" width="5%" height="auto"/></a>' : ' ').$row[4]."</section>";
}
} }  ?>