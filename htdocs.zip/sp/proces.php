<?php session_start();
	$nick = $_SESSION['nombre'];
	$text = $_POST['usermsg'];
	$para = str_replace(PHP_EOL,"",$_POST['para']);
	$texto = str_replace(PHP_EOL," ",$text);
	$texto = htmlspecialchars(str_replace("|","*",$texto));
	$item =$_GET['id_sala'];

if(file_exists("../usuarios/reg/".$nick))
{$link1 = "regYesYou"; }

if(file_exists("../usuarios/reg/".$id))
{$link2 = "regYesFor"; }

if(preg_match("/\.(gif|png|jpg|webp)$/", $_FILES['file']['name'])) { $ext = str_shuffle("aBhds1239054").".".pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
if(move_uploaded_file($_FILES['file']['tmp_name'], "../Com/img/".$ext))
 { $foto = $ext;} }
	
		
	
		if($_POST['pv'] != ""){ 
	if($_POST['usermsg'] !="") {
$fp = fopen("../sp/tmp/".$item.".box", 'a');
	fwrite($fp," ".$nick."875 ".$id."875 R42T03 |🔐".$nick."|".$para."|".$foto."|".$texto."|".PHP_EOL);
	fclose($fp); }  }
	 
	
	else { if($_POST['usermsg'] !="") {
	
$fp = fopen("../sp/tmp/".$item.".box", 'a');
	fwrite($fp, "nononow|".$nick."|".$para."|".$foto."|".$texto."|".PHP_EOL);
	fclose($fp);} } ?>