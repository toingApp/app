<?php if($_GET['color'] =="update") {
if(preg_match("/\.(gif|png|jpg)$/", $_FILES['file']['name'])) { $ext = $_GET['id_sala'].".".pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
if(move_uploaded_file($_FILES['file']['tmp_name'],"../sp/tmp/".$ext)) {   } }

$fondo_t = $_POST['fondo-titulo'];
$color_t= $_POST['color-titulo'];
$fondo_lA = $_POST['fondo-lineaA'];
$color_lA= $_POST['color-lineaA'];
$opacity_vi = $_POST['rang_vi'];
$fondo_lB = $_POST['fondo-lineaB'];
$color_lB= $_POST['color-lineaB'];
$opacity_ve = $_POST['rang_ve'];
$fondo_form = $_POST['fondo-form'];
$fondo_boton = $_POST['fondo-boton'];
$opacity_form = $_POST['rang_form'];

$file = file("tmp/".$_GET['id_sala'].".sp");
$fil = explode("|", $file[0]);
$setting ="$fondo_t^$color_t^$fondo_lA^$color_lA^$fondo_lB^$color_lB^$opacity_vi^$opacity_ve^$fondo_form^$fondo_boton^$opacity_form^";
$fp = fopen("tmp/".$_GET['id_sala'].".sp", "w");
fwrite($fp, "$fil[0]|$fil[1]|$fil[2]|$fil[3]|$fil[4]|$fil[5]|$fil[6]|$setting|$ext|");
header('Location: ../sp_sala?id_sala='.$_GET['id_sala']);
 } ?>