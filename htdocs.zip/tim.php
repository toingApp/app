<head>
  <meta charset="UTF-8">

</head> 
<?php $txt = $_POST["txt"];
echo utf8_encode($txt); ?>
<form method="post" action="tim.php">
<input type="text" name="txt"/>
<input type="submit"/>
</form>